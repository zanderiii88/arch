# Archipelago — Island Prototype v0.5.0

A phone-first, single-player island prototype. No build tools, paid services, API keys or server are required.

## Updating from your phone

If you have installed the **Publish Archipelago ZIP** workflow, download **Archipelago-v0.5.0.zip**, upload that ZIP directly to the repository root, and commit. Keep its original filename. The workflow selects the highest numbered release and publishes it automatically. No extraction on your phone is needed. Keep the existing workflow file in the repository.

## Upload to GitHub Pages without the ZIP workflow

1. Unzip this package on your computer.
2. Upload the **contents** to the root of a new GitHub repository. `index.html` must sit at the root, next to `game.js`, `style.css`, `sw.js`, `manifest.webmanifest` and the `assets` folder. Do not upload the ZIP itself.
3. In your repository, open **Settings → Pages**. Under Build and deployment select **Deploy from a branch**, then select your main branch and **/(root)**, and save.
4. Once GitHub reports the site is ready, open the provided Pages URL on your phone.
5. Optionally install it through your browser's **Add to Home Screen** or **Install app** option. On iPhone, use Safari's Share menu → Add to Home Screen.

Keep the assets folder and filenames unchanged. All paths are relative, so the game works under a repository subfolder. No custom domain is needed.

## Playing

- Choose New game, customise your appearance and enter your name.
- Tap land to walk. The character routes around solid obstacles.
- Tap a location sign to walk there. On arrival, tap the action button to enter its activity.
- You can step into the narrow band of shallows. Deeper water is blocked.
- Settings let you turn ambient animation or labels off, export/import your save, or return to the title.
- Continue resumes your character and last saved position.

## What is new in v0.5.0

### Island and character

The overworld character is larger. Diagonal walking favours a stable front/back view, with direction hysteresis to avoid flicker. The interface uses a softer system font. Rocks have been cleared from the shipping approach; the rock-pool coast remains intact.

Character creation has a central preview with left/right arrows for hair style, hair colour, headwear, eyewear, facial hair, tops, bottoms and footwear, plus skin swatches. Facial hair sits below eyewear. No gender categories or full outfits. Change your appearance through the wardrobe inside your shack.

### Calendar, boats and atmosphere

The calendar begins on Monday 1 June in the fictional game year 2026. **Three island minutes pass per second of active play.** Time pauses in menus, while the page is hidden, and while the game is closed. Daylight gradually changes into night.

A small boat icon opens the timetable: Ferry on Monday mornings, Trader on Wednesday mornings, Shop on Friday mornings. Morning visits run from 8am until noon. Available rows let you walk to the landing. Ferry journeys remain a preview.

The existing animated water includes moving surface texture, travelling wave crests, beach wash and dock ripples. Cached half-resolution distortion frames and a 30fps draw limit reduce load. Ambient animation can be disabled in Settings.

### Your beach shack

Enter Home to walk around a simple room with a kitchen counter, fridge, sofa and bed. Tap the floor to move, or use the Fridge and Go to bed buttons. Furniture blocks movement.

The fridge starts with bread, fruit, simple meals and water. Eat or drink immediately, or pack supplies for later. The backpack is available from the food/water bar in every playable area and pauses the current activity while open. It holds six supply types, with up to ten of each. Food and water decline gently; a full starting meter comfortably lasts the normal day.

Go to bed to watch your character sleep beneath the covers, with snoring, Zzz and an accelerated clock. At 8am they hop out of bed inside the house. Sleeping normally preserves catches and restores needs to at least 70%.

At 2am, or if either needs meter reaches zero, you doze off and mysteriously return to bed. You wake at 8am with a breakfast plate beside the bed. Tap the plate for a full food/water refill. Carried fish, rock-pool catches and food spoil; water, supplies and fridge food remain safe. Spoiled catches cannot be sold and can be discarded from the backpack. The overnight transition also recovers safely if the page closes during sleep.

### Rock pools

Visit Rock pools, then drag stones aside to uncover shore crabs, hermit crabs and small octopuses. Their legs or arms move as they scuttle. Some wait longer; others quickly head for cover. Pick up a creature and drag it into the bucket at the lower right. Held creatures cannot escape. Dropping one elsewhere returns it to the pool; a cancelled touch never counts as a catch.

When all four stones have been moved and the animals have been caught or hidden, search a fresh set. The bucket shows catches and sizes. Collection records persist, and fresh catches can be sold to the trader.

### Trading and shopping

- The trader buys fresh fish and rock-pool catches. Selling keeps discovery records.
- Bait costs 12 coins for five portions, is used automatically when available, and shortens the bite wait. Stronger line costs 35 coins and slows tension growth by 15%.
- The shop boat sells snacks, water, sunglasses and patterned shirts. Food and water refill the corresponding needs meters.
- Coins, catches, supplies, appearance, calendar, needs and fridge contents save automatically. Older saves gain the new fields without resetting progress.

## Earlier fishing improvements

- Fish alternate between calmer swimming and stronger pulls. Both the strength and duration change between bursts and catches, so tension no longer rises at a predictable rate.
- Hold to reel, release when tension rises. Basic fish remain forgiving: tight line pauses progress, with no line break, catch loss or time limit.
- Casting ripples appear for roughly 4.5–6.5 seconds, fade away and leave a quiet gap before the next opportunity. Once a cast starts, the ripple expiring does not cancel it.
- A bite gives a short vibration where the browser supports it, a gentle two-note ting when audio is enabled, and a visible exclamation mark. Sound is unlocked by entering fishing/casting. Browser and device settings may prevent sound or vibration.
- Sound and vibration can each be switched off in Settings. **Try bite alert** lets you check your phone's response.
- Returning to the island shows the catch total for this visit, counts by species and your biggest catch. You can return to the island or stay longer. Opening the bucket does not reset this visit.
- First catches and new personal best lengths get a note on the congratulations screen.

## Previous features

- Walking routes favour the painted sandy paths and take short access routes to each activity.
- Moving water texture and gentle surf wash along the main beach.
- A weathered turquoise timber beach shack with a corrugated roof.
- A larger red-and-white ferry with wheelhouse, passenger windows, funnel, lifebuoys and flag.
- A playable close-up fishing scene, with a walk to the end of the pier, casting, float, basic rod and turning reel.
- Two catchable fish: mackerel and pollock, each with a randomly generated length in centimetres.
- A congratulations screen and a catch bucket beside the character. Your bucket and fish discoveries are saved.

## How to fish

1. Tap Fishing on the island and let your character walk to the pier.
2. Tap **Go fishing**. The scene changes and your character walks to the end of the dock.
3. Wait for a ripple to appear and tap it before it fades. Wait a moment for a bite.
4. Hold **Hold to reel** to increase the catch progress.
5. Release when the tension gets high. If you keep holding into the red, progress pauses; release until tension falls below 40% to continue.
6. At 100%, the fish is landed. The congratulations message shows its species and length, and it is added to your bucket immediately.
7. Tap **Lovely! Keep fishing** for another cast. Open Bucket at the top to review catches, or use the arrow to see a recap before returning to the island.

Fishing works without bait; available bait is consumed automatically for a faster bite. There is no fish escape timer or line break. On a keyboard, hold Space or Enter while the reel button is focused.

## Included foundations

Start menu, appearance/name choices without gender categories, one portrait island, tap-to-walk routing, obstacle collision, walking behind buildings and trees, shallow-water foot effects, smoke, seagulls, save export/import, home-screen icons and offline cache support.

## Scope and limitations

Fishing, rock pools, sales, supply/cosmetic shopping, appearance changes, the home interior, sleep and basic food/water needs are playable. Beachcombing, crab pots, ferry journeys and house decorating remain previews. The fridge is generously stocked for this prototype; cooking and restocking are not implemented yet.

The island uses one painted map with mapped collision footprints and foreground silhouettes. The character, ferry and fishing props are drawn as simple pixel sprites. A soft bite alert is available; background sea ambience is not included yet.

Existing character saves load automatically; the new economy and character fields are added when missing. Saves stay in this browser on this device; clearing site data may delete them. Export a backup from Settings before changing browsers or devices. Initial loading and installation require HTTPS and a successful online visit before offline use.

## Updating

Upload the complete replacement package over the existing files. Reopen while online. Future releases should use a new cache name in sw.js and keep the save schema compatible or migrate it. Do not clear site data as a routine update step.

## Verification

JavaScript syntax and automated checks pass for fishing (100 simulated catches), bite cues, ripple expiry, recap totals and saves. New logic checks cover weekly boats, calendar rollover, gentle daily needs, normal sleep, 2am rescue, 8am waking, spoilage, safe fridge contents, breakfast, sleep recovery after reload, inventory limits, indoor routes, rock-pool capture/escape/cancel behaviour, appearance ordering and stable diagonal facing. The character screen, timetable, shack, fridge, sleep and rock pools were also inspected in a browser.

Actual iPhone/Android touch feel, installation, offline behaviour, audio/haptics and performance still need a real-phone check.

## Source

All game source is included: index.html, style.css, game.js and sw.js. Generated scenery is in assets/island.png, assets/fishing.png, assets/house.png and assets/pools.png. No third-party runtime or CDN dependencies. Version: 0.5.0.
