# Archipelago — Island Prototype v0.2.0

A phone-first, single-player island prototype. No build tools, paid services, API keys or server are required.

## Upload to GitHub Pages

1. Unzip this package on your computer.
2. Upload the **contents** to the root of a new GitHub repository. `index.html` must sit at the root, next to `game.js`, `style.css`, `sw.js`, `manifest.webmanifest` and the `assets` folder. Do not upload the ZIP itself.
3. In your repository, open **Settings → Pages**. Under Build and deployment select **Deploy from a branch**, then select your main branch and **/(root)**, and save.
4. Once GitHub reports the site is ready, open the provided Pages URL on your phone.
5. Optionally install it through your browser's **Add to Home Screen** or **Install app** option. On iPhone, use Safari's Share menu → Add to Home Screen.

Keep the assets folder and filenames unchanged. All paths are relative, so the game works under a repository subfolder. No custom domain is needed.

## Playing

- Choose New game, customise your appearance and enter your name.
- Tap land to walk. The character routes around solid obstacles.
- Tap a location sign to walk there. On arrival, tap the action button for its preview.
- You can step into the narrow band of shallows. Deeper water is blocked.
- Settings let you turn ambient animation or labels off, export/import your save, or return to the title.
- Continue resumes your character and last saved position.

## What is new in v0.2.0

- Walking routes favour the painted sandy paths and take short access routes to each activity.
- Moving water texture and gentle surf wash along the main beach.
- A weathered turquoise timber beach shack with a corrugated roof.
- A larger red-and-white ferry with wheelhouse, passenger windows, funnel, lifebuoys and flag.
- A playable close-up fishing scene, with a walk to the end of the pier, casting, float, basic rod and turning reel.
- Two catchable fish: mackerel and pollock, each with a randomly generated length in centimetres.
- A congratulations screen and a catch bucket beside the character. Your bucket and fish discoveries are saved.

## How to fish

1. Tap Fishing on the island and let your character walk to the pier.
2. Tap **Go fishing**. The scene changes and your character walks to the end of the dock.
3. Tap any of the three ripples to cast. Wait a moment for a bite.
4. Hold **Hold to reel** to increase the catch progress.
5. Release when the tension gets high. If you keep holding into the red, progress pauses; release until tension falls below 40% to continue.
6. At 100%, the fish is landed. The congratulations message shows its species and length, and it is added to your bucket immediately.
7. Tap **Lovely! Keep fishing** for another cast. Open Bucket at the top to review catches, or return to the island using the arrow.

There is no bait cost, fish escape timer or punishing failure in this first fishing system. On a keyboard, hold Space or Enter while the reel button is focused.

## Included foundations

Start menu, appearance/name choices without gender categories, one portrait island, tap-to-walk routing, obstacle collision, walking behind buildings and trees, shallow-water foot effects, smoke, seagulls, save export/import, home-screen icons and offline cache support.

## Scope and limitations

Fishing is now playable. Beachcombing, rock-pool searches, crab-pot catches, ferry journeys, shops and house decorating remain location previews. The 120 coins are still a fixed starting display.

The island uses one painted map with mapped collision footprints and foreground silhouettes. The character, ferry and fishing props are drawn as simple pixel sprites. There is no audio yet.

Your v0.1.0 character save loads automatically. Saves stay in this browser on this device; clearing site data may delete them. Export a backup from Settings before changing browsers or devices. Initial loading and installation require HTTPS and a successful online visit before offline use.

## Updating

Upload the complete replacement package over the existing files. Reopen while online. Future releases should use a new cache name in sw.js and keep the save schema compatible or migrate it. Do not clear site data as a routine update step.

## Verification

JavaScript syntax checks and automated logic tests passed for all six location routes, continuous obstacle avoidance, deep-water blocking, walkable ground behind the cottage, character creation, save/load and malformed-save rejection. Weighted path routing and the complete fishing loop (casting, bite, tension recovery, catches and saving) were also checked. The island and fishing scene were inspected in a browser. Actual iPhone/Android installation, offline behaviour and device performance still need a phone check.

## Source

All game source is included: index.html, style.css, game.js and sw.js. Generated scenery is in assets/island.png. No third-party runtime or CDN dependencies. Version: 0.2.0.
