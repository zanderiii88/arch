# Archipelago — Island Prototype v0.4.0

A phone-first, single-player island prototype. No build tools, paid services, API keys or server are required.

## Updating from your phone

If you have installed the **Publish Archipelago ZIP** workflow, download **Archipelago-v0.4.0.zip**, upload that ZIP directly to the repository root, and commit. Keep its original filename. The workflow selects the highest numbered release and publishes it automatically. No extraction on your phone is needed. Keep the existing workflow file in the repository.

## Upload to GitHub Pages without the ZIP workflow

1. Unzip this package on your computer.
2. Upload the **contents** to the root of a new GitHub repository. `index.html` must sit at the root, next to `game.js`, `style.css`, `sw.js`, `manifest.webmanifest` and the `assets` folder. Do not upload the ZIP itself.
3. In your repository, open **Settings → Pages**. Under Build and deployment select **Deploy from a branch**, then select your main branch and **/(root)**, and save.
4. Once GitHub reports the site is ready, open the provided Pages URL on your phone.
5. Optionally install it through your browser's **Add to Home Screen** or **Install app** option. On iPhone, use Safari's Share menu → Add to Home Screen.

Keep the assets folder and filenames unchanged. All paths are relative, so the game works under a repository subfolder. No custom domain is needed.

## Playing

- Choose New game, customise your appearance and enter your name.
- Tap land to walk. The character routes around solid obstacles.
- Tap a location sign to walk there. On arrival, tap the action button for its preview.
- You can step into the narrow band of shallows. Deeper water is blocked.
- Settings let you turn ambient animation or labels off, export/import your save, or return to the title.
- Continue resumes your character and last saved position.

## What is new in v0.4.0

### Water and atmosphere

The island and fishing scene share a new water renderer: a looping moving surface, travelling wave crests, beach wash sampled from the sandy shoreline, and expanding ripples around docks and boats. Inland scenery stays fixed. Distorted water frames are cached at half resolution and composited during play, with drawing capped at 30 fps to reduce device load. Ambient animation can still be disabled in Settings.

### Character choices

Six hair styles, seven hair colours, five skin tones, seven starter shirt colours, cap/beanie/no headwear, and beard/moustache/no facial hair. Visit Home to change your look without resetting your game. Purchased sunglasses and patterned shirts can also be changed there.

### Timetable and boats

Tap the small timetable above the island to expand ferry, trader and shop-boat arrivals. **One island minute is one second of active play.** Time pauses while you are away and while viewing a menu. Boat visits recur; no visits are missed while the game is closed.

For quick testing, the first trader arrives after 5 seconds of active play, the shop boat after 35 seconds and the ferry after 60 seconds. The trader stays 50 island minutes, the shop 55 and the ferry 35. They return every 180, 240 and 300 island minutes respectively. Tap an available timetable row or boat label to walk to the landing, then use the arrival button.

The ferry appears on its timetable, but journeys to other islands are still to come.

### Trading and shopping

- Trader: sell all fish or one species. Mackerel sell for about 0.45 coins per centimetre and pollock about 0.6, rounded to whole coins. Discoveries and size records remain after selling.
- Fishing supplies: five bait portions cost 12 coins; bait is used automatically on casts and shortens the bite wait. Stronger line costs 35 coins and permanently slows tension growth by 15%.
- Shop boat: picnic snacks (6), drinking water (4), sunglasses (35), striped shirt (45) and fancy flower shirt (60).
- New cosmetics are worn immediately; change them at the shack. Food and water can be enjoyed from Bag. They do not create hunger, thirst or stamina chores.
- Coins, supplies, ownership, fish records and island time save automatically. Older saves start with the original 120 coins and reconstruct records from fish in the bucket.

## Earlier fishing improvements

- Fish alternate between calmer swimming and stronger pulls. Both the strength and duration change between bursts and catches, so tension no longer rises at a predictable rate.
- Hold to reel, release when tension rises. Basic fish remain forgiving: tight line pauses progress, with no line break, catch loss or time limit.
- Casting ripples appear for roughly 4.5–6.5 seconds, fade away and leave a quiet gap before the next opportunity. Once a cast starts, the ripple expiring does not cancel it.
- A bite gives a short vibration where the browser supports it, a gentle two-note ting when audio is enabled, and a visible exclamation mark. Sound is unlocked by entering fishing/casting. Browser and device settings may prevent sound or vibration.
- Sound and vibration can each be switched off in Settings. **Try bite alert** lets you check your phone's response.
- Returning to the island shows the catch total for this visit, counts by species and your biggest catch. You can return to the island or stay longer. Opening the bucket does not reset this visit.
- First catches and new personal best lengths get a note on the congratulations screen.

## Previous features

- Walking routes favour the painted sandy paths and take short access routes to each activity.
- Moving water texture and gentle surf wash along the main beach.
- A weathered turquoise timber beach shack with a corrugated roof.
- A larger red-and-white ferry with wheelhouse, passenger windows, funnel, lifebuoys and flag.
- A playable close-up fishing scene, with a walk to the end of the pier, casting, float, basic rod and turning reel.
- Two catchable fish: mackerel and pollock, each with a randomly generated length in centimetres.
- A congratulations screen and a catch bucket beside the character. Your bucket and fish discoveries are saved.

## How to fish

1. Tap Fishing on the island and let your character walk to the pier.
2. Tap **Go fishing**. The scene changes and your character walks to the end of the dock.
3. Wait for a ripple to appear and tap it before it fades. Wait a moment for a bite.
4. Hold **Hold to reel** to increase the catch progress.
5. Release when the tension gets high. If you keep holding into the red, progress pauses; release until tension falls below 40% to continue.
6. At 100%, the fish is landed. The congratulations message shows its species and length, and it is added to your bucket immediately.
7. Tap **Lovely! Keep fishing** for another cast. Open Bucket at the top to review catches, or use the arrow to see a recap before returning to the island.

There is no bait cost, fish escape timer or punishing failure in this first fishing system. On a keyboard, hold Space or Enter while the reel button is focused.

## Included foundations

Start menu, appearance/name choices without gender categories, one portrait island, tap-to-walk routing, obstacle collision, walking behind buildings and trees, shallow-water foot effects, smoke, seagulls, save export/import, home-screen icons and offline cache support.

## Scope and limitations

Fishing, fish sales, basic supply/cosmetic shopping and changing your look at Home are playable. Beachcombing, rock-pool searches, crab-pot catches, ferry journeys and house decorating remain previews. Coins now change with sales and purchases.

The island uses one painted map with mapped collision footprints and foreground silhouettes. The character, ferry and fishing props are drawn as simple pixel sprites. A soft bite alert is available; background sea ambience is not included yet.

Existing character saves load automatically; the new economy and character fields are added when missing. Saves stay in this browser on this device; clearing site data may delete them. Export a backup from Settings before changing browsers or devices. Initial loading and installation require HTTPS and a successful online visit before offline use.

## Updating

Upload the complete replacement package over the existing files. Reopen while online. Future releases should use a new cache name in sw.js and keep the save schema compatible or migrate it. Do not clear site data as a routine update step.

## Verification

JavaScript syntax checks and automated logic tests passed for all six location routes, continuous obstacle avoidance, deep-water blocking, walkable ground behind the cottage, character creation, save/load and malformed-save rejection. Weighted path routing and the complete fishing loop were checked. v0.4.0 also passed 100 simulated catches across both species, varying pull strength, ripple expiry/respawn, cue mute switches, recap totals and older-save loading. The island, timetable and fishing scene were inspected in a browser. Economy checks cover boat windows, sales, insufficient funds, duplicate cosmetic purchases, records after sales, supplies, appearance editing and save compatibility. Renderer checks confirm water movement, shoreline sampling and unchanged inland scenery; these do not replace a real-phone performance check. Actual iPhone/Android installation, offline behaviour and device performance still need a phone check.

## Source

All game source is included: index.html, style.css, game.js and sw.js. Generated scenery is in assets/island.png. No third-party runtime or CDN dependencies. Version: 0.4.0.
