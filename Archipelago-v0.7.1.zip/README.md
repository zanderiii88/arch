# Archipelago — Island Prototype v0.7.1

A phone-first, single-player island game prototype. All source and assets are included. No build tools, API keys, paid services, server or CDN are required.

## Updating through GitHub

With the existing **Publish Archipelago ZIP** workflow installed, upload **Archipelago-v0.7.1.zip** directly to the repository root and commit. Keep its original filename and retain the existing workflow. The workflow selects the highest release number, extracts it and publishes the game. You do not need to extract it on your phone.

Without that workflow, extract the package and upload its contents so index.html, game.js, style.css, sw.js, manifest.webmanifest and assets sit together at the repository root. Enable Pages from your main branch, root folder. All paths are relative and support a repository subfolder.

Reopen the game online to update. Existing saves load automatically; do not clear site data as a normal update step. Export a backup in Settings before changing browsers or devices. Clearing browser data can delete your save.

## Update fix in v0.7.1

The HTML now loads game-v0.7.1.js and style-v0.7.1.css, so older cached game.js/style.css files cannot replace the new release. The title-screen version is written by the running JavaScript. Check for updates checks a small uncached version file and refreshes the page when a newer release is available. No saves or site storage are cleared. Future releases must give both application files a new versioned name and update index.html, version.json and sw.js together.

This is the full v0.7 content with an update-loading fix. Older ZIPs can stay in the repository; the publishing workflow selects the highest semantic version. Do not delete them as a troubleshooting step.

## Features from v0.7.0

### Post by the landing

A mailbox and delivery box sit beside the ferry dock. Tap their map labels to walk over, then choose Read post or Send a parcel. A small question mark gently pulses above the mailbox while unread post or an unclaimed gift is waiting. Read letters remain in the archive.

On completing a new-game arrival, the mailbox contains a local bulletin explaining that the storm damaged the ferry network and this is the first repaired landing. Other islands and route unlocks remain future work. Existing saves receive the bulletin and first request too.

The first request asks for one fresh mackerel at least 25 cm long. Later ferry visits can bring a hermit-crab request or a lost brass key to search for on the beach. At most two requests are active at once. Requests are optional, with no fine or other penalty for missing a date.

Each request states its last Monday collection date and reward. The initial window includes at least one full week. The request journal, available through Journal or the backpack, shows Finding items, Ready to send, Collected/reply due, Thank-you waiting and Completed. Expired requests stay visible without a penalty.

### Parcels and replies

1. Bring a suitable item in its bucket to the delivery box. Items in house storage must be taken out first.
2. Choose the request and qualifying catch/find. The game filters by species, size and freshness, and asks you to confirm the exact item before packing it.
3. A packed item leaves your bucket and is held safely as a sealed parcel. It does not spoil if you pass out. You can retrieve it until collection.
4. The ferry collects at noon on Monday when it leaves. If it is already alongside when you pack, that day's departure can collect your parcel. The date is shown before confirmation.
5. The following Monday ferry brings a thank-you letter. Read it and receive the enclosed gift. Rewards can only be claimed once, including after reload.

The first fish delivery rewards 35 coins and a shell ornament. The crab request rewards 45 coins, and the lost key 55 coins and a small plant. Decoration gifts go into the house chest, so a full backpack cannot block them. If you already own the decoration, the gift becomes an extra ten coins. Incoming mailbags and outgoing parcels briefly appear aboard the ferry.

Sleeping across a departure still processes a ready parcel correctly. The game remains paused while closed, hidden or in a menu; there are no real-world deadlines or notifications.

### Beachcombing tools

Visit Beach and choose Search the beach for a close-up shore with three free starter tools:

- **Rake:** drag up or down to pull sand aside. Repeated strokes leave furrows and small piles, gradually uncovering shells, sea glass, driftwood and smooth pebbles.
- **Metal detector:** drag to sweep. A signal meter and gentle beeps strengthen near buried metal. It ignores non-metal finds. A strong nearby signal marks a circle and enables the spade. Supported phones can give a small vibration; existing audio/vibration settings apply.
- **Spade:** drag within a marked circle to dig deeper and reveal a coin, bottle cap or lost brass key. It cannot dig arbitrary unmarked spots. Raking cannot uncover deep metal or rebury a dug find.

Once exposed, grab a find and drag it into the bucket at the lower right. A cancelled drag returns the item to the sand. The bucket stores finds separately from the six-space supply backpack. Beach finds do not spoil. Use New patch whenever you want a fresh search; already collected items remain yours. There is no activity countdown or escape timer. The usual island clock and gentle needs continue while actively searching.

Sand depth, revealed/marked finds and collected items save. Leaving and returning resumes the patch. An active lost-key request guarantees a buried key in a newly searched patch; press New patch if your current patch predates that request.

Beach discoveries appear in the journal. The house chest can hold beach finds, and the trader buys common finds. Lost keys are excluded from sales so you can return them to their owner.

### Chickens and home decorations

Three small chickens wander in the northern grass, pause to peck and occasionally flap. They stay on safe ground within their own area. They are ambient companions for now; feeding, eggs and a coop are not implemented. Ambient animation can be disabled in Settings.

The shop now sells a small plant (20 coins), a woven rug (25) and a shell ornament (15). Letters can also reward decorations. Use Decor inside the shack to place or put away each item at a fixed spot. Placing consumes its physical item from your backpack or chest; putting it away returns it to the chest. There is no free-placement editor yet.

## Existing playable systems

- Start menu, appearance and naming without gender categories, plus an animated new-game ferry arrival and loose introductory dialogue.
- Large character preview on the left, one cycle button per category on the right, seven hairstyles including close crop, hair/skin colours, hats, eyewear, facial hair, tops, bottoms and footwear. Breathing, blinking, smiles, occasional waves and a tap-triggered dance. Change your appearance through the house wardrobe.
- Tap-to-walk island routing that favours paths, furniture/building collision, walking behind mapped scenery and a narrow walkable band of shallows. The pools have a painted access path.
- Moving sea texture, wave crests, shoreline wash, dock ripples, chimney smoke and occasional gulls. Rendering is capped at 30fps, with cached water distortion frames. Ambient animation can be disabled.
- Calendar beginning Monday 1 June in the fictional game year 2026. Three game minutes pass per active second. The displayed clock advances in 15-minute steps; schedules and lighting stay continuous.
- Animated ferry on Monday mornings, trader on Wednesday mornings and shop boat on Friday mornings, from 8am to noon. Services become available after docking. Ferry journeys remain unavailable.
- Fishing close-up with casting opportunities that appear and fade, line casting, lure plop/splash/rings and a bobbing float. A bite gives a visible cue, optional sound and supported vibration. Hold to reel and release to ease variable tension. Basic mackerel and pollock are forgiving: no line break, escape timer or catch loss. Land at 100%, see species/size, keep it in the bucket and receive a visit recap on leaving.
- Rock pools with eight varied stones, animated shore crabs, hermit crabs and small octopuses, slow and fast movement, bucket dragging and safe pointer cancellation.
- Trader sales, bait, stronger line, shop supplies, clothing and cosmetics, persistent records and coins.
- A shack with kitchen counter, fridge, sofa, bed and storage chest. The indoor character is larger and quicker than on the island.
- Fridge shelves with product icons and quantity badges; eat/drink immediately or pack food and water. Six backpack supply spaces, up to ten per stack, with capacity shown on screen. Catches have separate buckets.
- Gentle food/water depletion. Full meters comfortably last a normal day. Normal sleep preserves catches and restores needs to at least 70%.
- A calm analogue sleep clock, snoring and a short overnight animation, waking in the house at exactly 8am. At 2am or empty needs, you mysteriously return to bed with breakfast beside it. Carried perishables and non-refrigerated chest perishables spoil; fridge contents and sealed delivery parcels stay safe.
- Save export/import, additive older-save migration, install icons and offline cache support after a successful online visit. Audio, vibration, installation and offline behaviour depend on the device/browser.

## Scope

Other islands, route unlocks, crab pots, cooking, fridge restocking, free furniture placement, chicken care and a longer story remain future work. This build contains three request templates that can recur across later ferry visits, rather than a large authored quest library. Requests currently need one item each.

The shore, island and interior backgrounds use generated pixel artwork. Characters, tools, movable sand, finds, animals and small props are code-native sprites. The interface uses bundled Nunito under the SIL Open Font License; see assets/Nunito-LICENSE.txt. There are no external font or runtime dependencies.

## Validation

JavaScript syntax, HTML IDs, local assets and the release archive were checked. Automated checks cover prior life/fishing/storage systems and 100 simulated fish catches, plus letter migration, request matching, deadline cutoffs, parcel retrieval and safe holding, Monday collection and next-ferry replies, duplicate reward prevention, decoration transfers, detector filtering, marked-only digging, gradual sand exposure, drag cancellation/duplicate pickup prevention, bucket/chest transfers, beach save recovery and chickens staying within safe northern ground.

Native canvas checks render the island props, chickens, beach tools and sand, alongside existing scenes, and verify every location remains reachable. Browser checks cover the mailbox bulletin, first request, request journal and beach interaction. Actual iPhone/Android touch feel, performance, audio/haptics, installation and offline update behaviour still need a real-phone check.

## Source and artwork

Game source: index.html, style.css, game.js and sw.js. Generated backgrounds: assets/island.png, fishing.png, house.png, pools.png and beach.png. The new beach backdrop was created with the built-in image-generation tool: an overhead portrait pixel-art shore, turquoise shallows across the top, open warm sand for interactive searching and sparse vegetation at the far edge, without interface, tools or visible buried objects. Interactive sand and all tool behaviour are implemented in game.js.

Version: 0.7.1.
